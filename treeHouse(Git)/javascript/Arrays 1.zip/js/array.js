//const planets =[
//  `Mercury`, 
//  `Venus`, 
//  `Earth`, 
//  `Mars`
// ];
//
//
//console.log(planets[2]);
//
//planets.push(`Pluto`);
//
//console.log(planets)
//
//const numbers=[];
//
//
////displays the array in a line with whatever we add in the `` between the elements
//console.log(planets.join(`, `));
//
//
////returns true if in the array
//console.log(planets.includes(`Venus`));
//
////returns false if not in the array
//console.log(planets.includes(`Potato`));
//
//
////indexOf returns 1 if it is in the array, and
//console.log(planets.indexOf(`Venus`));
//
////returns -1 of not in the array
//console.log(planets.indexOf(`Potato`));
//


const planets = ['Earth','Mars','Saturn','Mecury','Jupiter','Venus','Uranus','Neptune'];

console.log(planets.join(`, `));

console.log(planets.indexOf(`Saturn`));