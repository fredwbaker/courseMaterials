const middle = ['lettuce', 'cheese', 'patty'];
let burger = ['top bun', 'bottom bun'];


//adding the first array (middle) into the second array just plugs the first array into this one, it doesn't combine them
//const burger = ['top bun', middle, 'bottom bun'];

//using the spread operator (...) before the added array, we can add the two arrays into one
burger = ['top bun', ... middle, 'bottom bun'];

console.log(burger);

const numbers = [5, 10, 15, 20];

//returns the highest number in an array

console.log(Math.max(...numbers));

//returns the lowest number in an array
console.log(Math.min(...numbers));

console.log(burger.length);

for(let i=0; i<burger.length; i++) {
  console.log(burger[i]);
}