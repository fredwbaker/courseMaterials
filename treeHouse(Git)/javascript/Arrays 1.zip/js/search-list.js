const inStock = ['pizza', 'cookies', 'eggs', 'apples', 'milk', 'cheese', 'bread', 'lettuce', 'carrots', 'broccoli', 'potatoes', 'crackers', 'onions', 'tofu', 'limes', 'cucumbers'];
const search = prompt('Search for a product.');
let message;

//pulled from StackOverflow to make sentencecase: https://stackoverflow.com/questions/24263727/use-tosentencecase-on-function-parameter-javascript


String.prototype.toSentenceCase= function() {
return this.charAt(0).toUpperCase() + this.slice(1).toLowerCase()};



if( !search){
  message=`<strong>In Stock: </strong> ${inStock.join(`, `)}`;
} else if (inStock.includes(search.toLowerCase())) {
  
//  console.log(`Yes! It's in Stock!`);
  message = `Yes! <strong>${search.toSentenceCase()}</strong> is in stock! It's # ${inStock.indexOf(search.toLowerCase()) +1} on the list!`

} else {
  
  message = `<h2>Sorry. <strong>${search.toSentenceCase()}</strong> is NOT in stock. Try something else?</h2>`



//  console.log(`Sorry. Try something else?`);
  
};

document.querySelector(`main`).innerHTML = `<p> ${message} </p>`;
