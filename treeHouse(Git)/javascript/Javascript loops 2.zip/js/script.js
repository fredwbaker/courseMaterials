
//Refactor Code Challenge:
//for(let j = 2; j<=24; j+=2){
//  console.log(j);
//};
//
////
////console.log(2);
////console.log(4);
////console.log(6);
////console.log(8);
////console.log(10);
////console.log(12);
////console.log(14);
////console.log(16);
////console.log(18);
////console.log(20);
////console.log(22);
////console.log(24);
//





//LOOPS:





let html = '';
//let red;
//let green;
//let blue;
//let randomRGB;


//Guil's code:

//create a random value:

//const randomValue = () => Math.floor(Math.random() * 256);
//
////create a random color function:
//function randomRGB(){
//  const color = `rgb( ${randomValue()}, ${randomValue()}, ${randomValue()} )`; 
//  return color;  
//}


const randomValue = () => Math.floor(Math.random() * 256);

//revise the random color function to take a value:
function randomRGB(value){
  const color = `rgb( ${value()}, ${value()}, ${value()} )`; 
  return color;  
}


for(i=0; i<10; i++){

  html += `<div style="background-color: ${randomRGB(randomValue)}">${i+1}</div>`;
} document.querySelector('main').innerHTML = html;



























////My refactor:
//for(i=0; i<10; i++){
//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">${i+1}</div>`;
//}
//
//document.querySelector('main').innerHTML = html;

























//
//let randomColor = function ( ){
//
//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`; 
//};
//


//for(i=0; i<10; i++){
//
//  randomColor();
//  html += `<div style="background-color: ${randomRGB}">${i+1}</div>`;
//} document.querySelector('main').innerHTML = html;



//original code: 


//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">1</div>`;

//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">2</div>`;
//
//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">3</div>`;
//
//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">4</div>`;
//
//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">5</div>`;
//
//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">6</div>`;
//
//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">7</div>`;
//
//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">8</div>`;
//
//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">9</div>`;
//
//red = Math.floor(Math.random() * 256);
//green = Math.floor(Math.random() * 256);
//blue = Math.floor(Math.random() * 256);
//randomRGB = `rgb( ${red}, ${green}, ${blue} )`;
//html += `<div style="background-color: ${randomRGB}">10</div>`;


//document.querySelector('main').innerHTML = html;