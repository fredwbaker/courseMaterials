const main = document.querySelector('main');

//shows 0-9. Don't forget the += or it will only show the final number!
//let html =``;
//
//for(let i = 0; i < 10;  i++){
//  
//  html+=`<div>${i}</div>`;
//}
//
//main.innerHTML = html;


////to show 1-10
//let html =``;
//
//for(let i = 1; i <= 10;  i++){
//  
//  html+=`<div>${i}</div>`;
//}
//
//main.innerHTML = html;



////Could also show:
//
//let html =``;
//
//for(let i = 0; i < 10;  i++){
//  
//  html+=`<div>${i +1}</div>`;
//}
//
//main.innerHTML = html;



//
//////to show 1-1000
//let html =``;
//
//for(let i = 1; i <= 1000;  i++){
//  
//  html+=`<div>${i}</div>`;
//}
//
//main.innerHTML = html;
//

////to count by 5s
//let html =``;
//
//for(let i = 5; i <= 100;  i+=5){
//  
//  html+=`<div>${i}</div>`;
//}
//
//main.innerHTML = html;

//
////Can put the innerHTML line inside of the for loop. This makes the browser do extra work bc it updates the string each iteration. 
//let html =``;
//
//for(let i = 5; i <= 100;  i+=5){
//  
//  html+=`<div>${i}</div>`;
//  main.innerHTML = html;
//}




