//function getRandomNumber(upper) {
//  return Math.floor( Math.random() * upper ) + 1;
//}
//
////the while loop: 
////let counter=0;
////
////while (counter < 10){
////    console.log(`The random number is ${getRandomNumber(10)}!`);
////  
////    counter+=1;
////}
//
//
//
////the for loop uses the same components as the while loop, but is more compact
//
//for(let counter = 0; counter < 10; counter +=1 ) {
//
//      console.log(`The random number is ${getRandomNumber(10)}!`);
//}
//
//
//for(let i = 0; i < 10; i ++ ) {
//
//      console.log(`The random number is ${getRandomNumber(10)}!`);
//}

for( let i=5; i<=100; i++) {
  console.log(i);
}