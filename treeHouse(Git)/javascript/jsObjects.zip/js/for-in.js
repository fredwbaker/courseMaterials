const person = {
  name: 'Edward',
  nickname: 'Duke',
  city: 'New York',
  age: 37,
  isStudent: true,
  skills: ['JavaScript', 'HTML', 'CSS']
};

for(let key in person){
  console.log(key);//logs the property
  console.log(person[key]);//logs the property VALUE
}


const composer = {
  name: 'Edward Ellington',
  nickname: 'Duke',
  genres: ['jazz', 'swing'],
  instrument: 'piano'
};

for(let key in composer){
  console.log(`${key}:${composer[key]}`);
}