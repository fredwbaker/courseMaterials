////PHASE 1
//// 1. Create a multidimensional array to hold quiz questions and answers
//
//const quiz = [
//  ['What color is the sky?', 'blue'], 
//  ['What color is the grass?', 'green'],
//  ['What is the square root of 9?', '3'], 
//  ['What is the racecar spelled backwards?', 'racecar'],
//  
//]
//
////console.log(quiz[0]);
//// 2. Store the number of questions answered correctly
//
//let correctAnswers = 0;
//
//
//
///* 
//  3. Use a loop to cycle through each question
//      - Present each question to the user
//      - Compare the user's response to answer in the array
//      - If the response matches the answer, the number of correctly
//        answered questions increments by 1
//*/
//
//
//
//for(let i=0; i < quiz.length; i++){
//
//  let question = quiz[i] [0];
//  let answer = quiz[i] [1];
//  let response = prompt(question);
//
//  else if (response === answer) {
//    correctAnswers++;
//  }
//}
// 
//
//
//// 4. Display the number of correct answers to the user
//
//
//let html=`<h1>You got ${correctAnswers} of 4 question(s) correct!</h1>`;
//
//document.querySelector(`main`).innerHTML = html;












//PHASE 2
// 1. Create a multidimensional array to hold quiz questions and answers

const quiz = [
  ['What color is the sky?', 'blue'], 
  ['What color is the grass?', 'green'],
  ['What is the square root of 9?', '3'], 
  ['What is racecar spelled backwards?', 'racecar'],
  
]

//console.log(quiz[0]);
// 2. Store the number of questions answered correctly

let correctAnswers = 0;
let quizCorrect =[];
let quizIncorrect =[];


/* 
  3. Use a loop to cycle through each question
      - Present each question to the user
      - Compare the user's response to answer in the array
      - If the response matches the answer, the number of correctly
        answered questions increments by 1
*/



for(let i=0; i < quiz.length; i++){

  let question = quiz[i] [0];
  let answer = quiz[i] [1];
  let response = prompt(question);

  if (response === answer) {
    correctAnswers++;
    quizCorrect.unshift(quiz[i][0])
  } else {
      quizIncorrect.unshift(quiz[i][0])
  }
}
 
//Guil's piece:
function createListItems(arr) {
  let items = '';
  for (let i = 0; i < arr.length; i++) {
    items += `<li>${arr[i]}</li>`;
  }
  return items;
}

// 4. Display the number of correct answers to the user


//let html=`<h1>You got ${correctAnswers} of 4 question(s) correct!</h1>`;
//let correct=`<h2>You got these correct: ${quizCorrect}</h2>`;
//let incorrect=`<h2>You got these incorrect: ${quizIncorrect}</h2>`;

document.querySelector(`main`).innerHTML = `<h1>You got ${correctAnswers} of 4 question(s) correct!</h1>
<h2>You got these correct:</h2> <p>${createListItems(quizCorrect)}</p>
<h2>You got these incorrect:</h2> <p>${createListItems(quizIncorrect)}</p>`;

